$(document).ready(function(){

	$("#phone").mask("+7 (999) 999-9999");

	$("#submit").click(function(){

		var a = $('#phone');
		var b = parseInt(a.val().replace(/\D+/g,""));
		var c = $('label[for="phone"]');
		c.removeClass('error');
		c.removeClass('success');

		if(a.val() == '') {
			c.addClass('error');

		} else {
			c.addClass('success');
		}
	})

	$("#phone").keyup(function(){

		var a = $('#phone');
		var b = parseInt(a.val().replace(/\D+/g,""));
		var c = $('label[for="phone"]');

		c.removeClass('error');
		c.removeClass('success');

		if(b == '' || b == '7' || b <= '70000000000') {
			c.addClass('error');
			$('#submit').attr('disabled', true);
		} else {
			c.addClass('success');
			$('#submit').attr('disabled', false);
		}
	})
})