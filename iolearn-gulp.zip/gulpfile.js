// gulpfile.js
var gulp = require("gulp");
var sass = require("gulp-sass");
var browserSync = require("browser-sync").create();

function style() {
    // Where should gulp look for the sass files?
    // My .sass files are stored in the styles folder
    // (If you want to use scss files, simply look for *.scss files instead)
    return (
        gulp
            .src("app/sass/*.sass")
 
            // Use sass with the files found, and log any errors
            .pipe(sass())
            .on("error", sass.logError)
 
            // What is the destination for the compiled file?
            .pipe(gulp.dest("app/css"))
            .pipe(browserSync.stream())
    );
}
 
// Expose the task by exporting it
// This allows you to run it from the commandline using
// $ gulp style
exports.style = style;

function reload() {
    browserSync.reload();
}

function watch() {
    browserSync.init({
        // You can tell browserSync to use this directory and serve it as a mini-server
        server: {
            baseDir: "app"
        },
        notify: false
        // If you are already serving your website locally using something like apache
        // You can use the proxy setting to proxy that instead
        // proxy: "yourlocal.dev"
    });
    gulp.watch("app/sass/*.sass", style);
    gulp.watch("app/*.html", reload);
}
    
// Don't forget to expose the task!
exports.watch = watch

